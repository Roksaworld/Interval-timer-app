нужен node js на десктоп

установить модули --> npm install

собрать проект в dev --> npm run start

собрать проект --> npm run игшдв
